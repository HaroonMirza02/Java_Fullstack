create  table userdata(id int , name varchar(20),email varchar(30),age int , gender char);
insert into userdata values(101,'Tom','email',90,'M');
insert into userdata values(102,'Andrew','email',90,'M');
insert into userdata values(103,'Tony','email',90,'M');
insert into userdata values(104,'Bob','email',90,'M');
insert into userdata values(105,'Sam','email',90,'F');